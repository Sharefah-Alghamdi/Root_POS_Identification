def decode_3(decoded_sentence, root):
    decoded_words = {}
    homeless_nodes = {}
    # 1 : ['The', 'DT', '+1', 'det', 'NN']
    for index_of_word in decoded_sentence:
        #print("decoded_sentence= ")
        #print(decoded_sentence)
        #print("index_of_word= ")
        #print(index_of_word)
        if not index_of_word == 0:

            word_line = decoded_sentence.get(index_of_word)
            #print("word_line= ")
            #print(word_line)
            info_about_word = word_line
            #print("info_about_word= ")
            #print(info_about_word)
            found_head = False
            if not word_line[2]=="-EOS-" and not word_line[2]=="-BOS-":
                position_head = int(word_line[2])
                post_of_head = word_line[3]
                abs_posit = abs(position_head)
                abs_posit_minus = abs_posit - 1
                abs_posit_plus = abs_posit + 1
                #print("position_head/post_of_head/abs_posit/abs_posit_minus/abs_posit_plus")
                #print(str(position_head)+"/"+str(post_of_head)+"/"+str(abs_posit)+"/"+str(abs_posit_minus)+"/"+str(abs_posit_plus))               

                if position_head < 0:
                    words_full_info = assignHeadL(index_of_word, info_about_word, post_of_head,
                                                  decoded_sentence, abs_posit)
                    #print("words_full_info1= ")
                    #print(words_full_info)
                    if words_full_info:
                        decoded_words.update({index_of_word: words_full_info})
                        found_head = True

                    elif not abs_posit_minus == 0:
                        words_full_info = assignHeadL(index_of_word, info_about_word, post_of_head,
                                                      decoded_sentence, abs_posit_minus)
                        if words_full_info:
                            decoded_words.update({index_of_word: words_full_info})
                            found_head = True

                    else:
                        words_full_info = assignHeadL(index_of_word, info_about_word, post_of_head,
                                                      decoded_sentence, abs_posit_plus)
                        if words_full_info:
                            found_head = True
                            decoded_words.update({index_of_word: words_full_info})
                    #print("### words_full_info |position_head < 0| ### ")
                    #print(words_full_info)

                    # find head with the relative position +1,+2....
                elif position_head > 0:
                    found_head = False
                    words_full_info = assignHeadR(index_of_word, info_about_word, post_of_head,
                                                  decoded_sentence, abs_posit)
                    if words_full_info:
                        decoded_words.update({index_of_word: words_full_info})
                        found_head = True

                    elif not abs_posit_minus == 0:
                        words_full_info = assignHeadR(index_of_word, info_about_word, post_of_head,
                                                      decoded_sentence, abs_posit_minus)
                        if words_full_info:
                            decoded_words.update({index_of_word: words_full_info})
                            found_head = True

                    else:
                        words_full_info = assignHeadR(index_of_word, info_about_word, post_of_head,
                                                      decoded_sentence, abs_posit_plus)
                        if words_full_info:
                            decoded_words.update({index_of_word: words_full_info})
                            found_head = True
                    #print("### words_full_info |position_head > 0| ### ")
                    #print(words_full_info)
                if not found_head:
                    words_full_info = {1: index_of_word, 2: info_about_word[0],
                                       3: "_", 4: info_about_word[1],
                                       5: -1, 6: info_about_word[4]} # sharefah from 3 to 4
                    homeless_nodes.update({index_of_word: words_full_info})
                    decoded_words.update({index_of_word: words_full_info})
                    #print("### words_full_info |not found_head| homeless_nodes ### ")
                    #print(words_full_info)
            else:
                words_full_info = {1: index_of_word, 2: info_about_word[0],
                                       3: "_", 4: info_about_word[1],
                                       5: -1, 6: root}
                homeless_nodes.update({index_of_word: words_full_info})
                decoded_words.update({index_of_word: words_full_info})

                #print("words_full_info of index 0")
                #print(words_full_info)

    #print(" ---- decoded_words ------ ")
    #for key, value in decoded_words.items() :
      #print (key, value)
      #break
    return decoded_words, homeless_nodes

def assignHeadL(node_index, info_about_word, head, decoded, abs_posit):
    # assign new head to the wrong roots

    count_posit = 0

    # find head with the relative position -1,-2....
    for index in range(node_index - 1, -1, -1):
            info_candidate_word = decoded[index]
            postag_candidate = info_candidate_word[1]
            if postag_candidate == head:
                count_posit += 1
                if abs_posit == count_posit:
                    words_full_info = {1: node_index, 2: info_about_word[0],
                                       3: "_", 4: info_about_word[1],
                                       5: index, 6: info_about_word[4]}# sharefah from 3 to 4

                    return words_full_info


def assignHeadR(node_index, info_about_word, head, decoded, abs_posit):
    count_posit = 0

    # find head with the relative position +1,+2....
    for index in range(node_index + 1, len(decoded)):
        info_candidate_word = decoded[index]

        postag_candidate = info_candidate_word[1]
        if postag_candidate == head:
            count_posit += 1
            if abs_posit == count_posit:
                words_full_info = {1: node_index, 2: info_about_word[0],
                                   3: "_", 4: info_about_word[1],
                                   5: index, 6: info_about_word[4]} # sharefah from 3 to 4
                return words_full_info

def decode_id(decoded_sentence, root):

    decoded_words = {}
    homeless_nodes = {}
    # 1 : ['The', 'DT', '0', '12', 'SBJ']
    for index_of_word in decoded_sentence:
        #print("decoded_sentence= ")
        #print(decoded_sentence)
        #print("index_of_word= ")
        #print(index_of_word)
        if not index_of_word == 0:

            word_line = decoded_sentence.get(index_of_word)
            #print("word_line= ")
            #print(word_line)
            info_about_word = word_line
            #print("info_about_word= ")
            #print(info_about_word)
            found_head = False
            if not word_line[2]=="-EOS-" and not word_line[2]=="-BOS-":
                
                position_head = int(word_line[3])
                

                if position_head >=0 and  position_head<len(decoded_sentence):
                    words_full_info = {1: index_of_word, 2: info_about_word[0],
                                       3: "_", 4: info_about_word[1],
                                       5: position_head, 6: info_about_word[4]}
                    decoded_words.update({index_of_word: words_full_info})

                else:
                    words_full_info = {1: index_of_word, 2: info_about_word[0],
                                       3: "_", 4: info_about_word[1],
                                       5: -1, 6: info_about_word[4]} # sharefah from 3 to 4
                    homeless_nodes.update({index_of_word: words_full_info})
                    decoded_words.update({index_of_word: words_full_info})
                    #print("### words_full_info |not found_head| homeless_nodes ### ")
                    #print(words_full_info)
            else:
                words_full_info = {1: index_of_word, 2: info_about_word[0],
                                       3: "_", 4: info_about_word[1],
                                       5: -1, 6: root}
                homeless_nodes.update({index_of_word: words_full_info})
                decoded_words.update({index_of_word: words_full_info})

                #print("words_full_info of index 0")
                #print(words_full_info)
        
    #print(" ---- decoded_words ------ ")
    #for key, value in decoded_words.items() :
      #print (key, value)
      #break
    return decoded_words, homeless_nodes



def decode_LR(decoded_sentence, root):
    decoded_words = {}
    homeless_nodes = {}
    # 1 : ['The', 'DT', 'L', '1', 'SBJ']
    for index_of_word in decoded_sentence:
        #print("decoded_sentence= ")
        #print(decoded_sentence)
        #print("index_of_word= ")
        #print(index_of_word)
        if not index_of_word == 0:

            word_line = decoded_sentence.get(index_of_word)
            #print("word_line= ")
            #print(word_line)
            info_about_word = word_line
            #print("info_about_word= ")
            #print(info_about_word)
            found_head = False
            if not word_line[2]=="-EOS-" and not word_line[2]=="-BOS-":
                if word_line[2]=="L":
                  position_head = index_of_word-int(word_line[3])
                elif word_line[2]=="R":
                  position_head = index_of_word+int(word_line[3])

                if position_head >=0 and  position_head<len(decoded_sentence):
                    words_full_info = {1: index_of_word, 2: info_about_word[0],
                                       3: "_", 4: info_about_word[1],
                                       5: position_head, 6: info_about_word[4]}
                    decoded_words.update({index_of_word: words_full_info})

                else:
                    words_full_info = {1: index_of_word, 2: info_about_word[0],
                                       3: "_", 4: info_about_word[1],
                                       5: -1, 6: info_about_word[4]} # sharefah from 3 to 4
                    homeless_nodes.update({index_of_word: words_full_info})
                    decoded_words.update({index_of_word: words_full_info})
                    #print("### words_full_info |not found_head| homeless_nodes ### ")
                    #print(words_full_info)
            else:
                words_full_info = {1: index_of_word, 2: info_about_word[0],
                                       3: "_", 4: info_about_word[1],
                                       5: -1, 6: root}
                homeless_nodes.update({index_of_word: words_full_info})
                decoded_words.update({index_of_word: words_full_info})

                #print("words_full_info of index 0")
                #print(words_full_info)
        
    #print(" ---- decoded_words ------ ")
    #for key, value in decoded_words.items() :
      #print (key, value)
      #break
    return decoded_words, homeless_nodes