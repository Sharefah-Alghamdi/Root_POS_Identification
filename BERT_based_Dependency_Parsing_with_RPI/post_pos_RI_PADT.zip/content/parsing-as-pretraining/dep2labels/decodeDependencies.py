from dep2labels.labeling import Encoding


def convertToDependency(multitag, multitask_char):

    multitag_dep = multitag.split(multitask_char)
    #print(multitag_dep)
    #for 6 task
    if len(multitag_dep)>3:
        return multitag_dep[3:]
    #for single task
    else:
        return multitag_dep[0:3]

def decode(output_from_nn,head_enc, path_output, split_char, language,do_test):
        labels = []
        words_with_dependencies = []
        sent_with_depend = {}
        sent_nb = 1
        count_words = 1
        enc = Encoding()
        for l in output_from_nn:
            #print(l)

            if l != "\n":
                word, postag, label_raw = l.strip().split("\t")[0], l.strip().split("\t")[1], \
                                          l.strip().split("\t")[-1]
                #word,postag,label_raw = l.strip().split("\t")[0], "\t".join(l.strip().split("\t")[1]), l.strip().split("\t")[-1]
                #print("word, postag, label_raw")
                #print(word, postag, label_raw)
                if not word == "-BOS-" and not word == "-EOS-":
                    label_dependency = convertToDependency(label_raw, split_char)
                    #if label_dependency[0] == "-EOS-":
                      #print("label_dependency is EOS")


                    if label_dependency is not None:

                        label_dependency.insert(0, postag)
                        label_dependency.insert(0, word)
                        words_with_dependencies.append(label_dependency)
                        count_words+=1

            else:
                count_words = 1
                sent_with_depend.update({sent_nb:words_with_dependencies})
                sent_nb+=1
                words_with_dependencies=[]

        enc.decode(sent_with_depend, head_enc, path_output, language,do_test)
        


