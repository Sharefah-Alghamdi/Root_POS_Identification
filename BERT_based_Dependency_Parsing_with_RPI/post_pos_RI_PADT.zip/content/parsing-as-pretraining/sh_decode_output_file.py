
from dep2labels.decodeDependencies import decode

def sh_output(sh_input,sh_output,head_enc,do_test):
    with open(sh_input) as f:
        
        lines = f.readlines()
        print (decode(lines, head_enc, sh_output, "@","Arabic",do_test)) 

